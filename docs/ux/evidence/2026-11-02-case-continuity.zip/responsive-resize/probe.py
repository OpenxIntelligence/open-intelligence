import json
from pathlib import Path
import shutil
import sys

sys.path.insert(0, '/workspace/scratch/3e092c839f43/open-intelligence/tests')
from workspace_navigation_journey import Journey, browser_session

legacy_wait = '--legacy-wait' in sys.argv
output = Path('/tmp/oi-ux-ci-nav-resize-probe') / ('legacy' if legacy_wait else 'fixed')
output.mkdir(exist_ok=True)
if legacy_wait:
    def inner_width_only(self, width):
        self.cd.command('Emulation.setDeviceMetricsOverride', {
            'width': width, 'height': 844 if width < 768 else 1000,
            'deviceScaleFactor': 1, 'mobile': False,
        })
        self.cd.wait(f'innerWidth === {width}', f'{width}px viewport')
    Journey.viewport = inner_width_only
report = {'checks': [], 'screenshots': [], 'browser_errors': []}
chrome = '/tmp/oi-ux-browser-bin/google-chrome'
state = """({width:innerWidth, mobile:matchMedia('(max-width: 760px)').matches,
  railHidden:document.querySelector('#workspace-rail').hidden,
  toggleDisplay:getComputedStyle(document.querySelector('#menu-toggle')).display,
  view:document.body.dataset.view, events:window.resizeProbeEvents})"""
outcome = {'attempts': 0, 'failure': None}
with browser_session(chrome, output, report) as j:
    j.view('incoming-board')
    j.cd.evaluate("window.resizeProbeEvents=[]; matchMedia('(max-width: 760px)').addEventListener('change', event => resizeProbeEvents.push({mobile:event.matches, time:performance.now()}))")
    for attempt in range(1, 101):
        outcome['attempts'] = attempt
        j.viewport(390)
        j.cd.wait("document.querySelector('#workspace-rail').hidden", 'closed mobile rail')
        j.viewport(768)
        j.go('incoming-board')
        try:
            j.follow_nav('incoming-board')
        except AssertionError as error:
            outcome['failure'] = str(error)
            outcome['immediate'] = j.cd.evaluate(state)
            j.cd.evaluate('new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)))')
            outcome['after_render'] = j.cd.evaluate(state)
            break
outcome['browser_errors'] = report['browser_errors']
(output / 'resize-probe.json').write_text(json.dumps(outcome, indent=2) + '\n')
print(json.dumps(outcome))
