# Open Intelligence: baseline failure diagnosis

Date: 2026-11-02 UTC

Baseline commit: `334d863b2206b290c02cd2606dcb93c93afe3a68`

Scope: read-only source inspection and one targeted rerun of the two Python test methods that failed in the initial full suite. No backend, test, browser-harness, or other product source changes were made. This is temporary engineering evidence for the frontend redesign, not clinical validation.

## Results and provenance

| Run | Result | Evidence |
|---|---|---|
| Initial full Python suite | 345 tests in 60.462 seconds; two failing subtests and one error; exit 1 | `python-tests.log`, `python-tests-result.json` |
| Targeted rerun, two methods | 2 tests in 0.949 seconds; one failing literature subtest; workspace method passed; exit 1 | `python-targeted-rerun.log`, `python-targeted-rerun-result.json` |
| Initial JavaScript suite | 7 test files passed, none failed or skipped; exit 0 | `javascript-tests.log`, `javascript-tests-result.json` |
| Initial UI glance journey | Failed before browser startup: `Chromium unavailable: UI is not verified`; exit 1 | `ui-glance-journey.log`, `ui-glance-journey-result.json` |

The initial checkout was clean before and after the full baseline. At the start of diagnosis, the parent had added untracked design-plan and research documentation. During this work, the parent committed those three documentation files as `e485d8a0a7af87fc160c54d36b1586b24fa4d92c`. A final explicit comparison against the baseline commit confirmed that all five test and backend files inspected below were unchanged. The one targeted rerun used those unchanged files. No UI retry was performed during this diagnosis.

The targeted command was equivalent to:

```bash
PYTHONPATH=src:tests python3 -m unittest -v \
  test_literature_http.LiteratureHttpTests.test_known_and_unknown_provider_failures_use_fixed_query_free_errors \
  test_workspace_start_http.WorkspaceStartHttpTests.test_fresh_database_to_case_and_exact_uploaded_bytes_survives_reopen
```

Adding `tests` to `PYTHONPATH` makes the existing test modules importable by method name; it does not change their code. Localhost access was granted through the requested command escalation. Provider calls in the literature test are mocked offline.

## 1. Literature request lock: response/cleanup race

### Observed

The initial full suite produced two failing subtests in `LiteratureHttpTests.test_known_and_unknown_provider_failures_use_fixed_query_free_errors`, both labeled `error='LiteratureError'`.

The single targeted rerun reproduced the same assertion failure once, this time in the `RuntimeError` subtest:

```text
tests/test_literature_http.py:201
self.assertFalse(self.handler.literature_request_lock.locked())
AssertionError: True is not false
```

The status-code, fixed error-code, and query-redaction assertions before the lock assertion passed. The subsequent mutated `LiteratureError` subtest also passed. The rerun log records the expected one 422 response and five 502 responses, with no unexpected 429 response.

### Source evidence

- `tests/test_literature_http.py` creates a `ThreadingHTTPServer` and a new class-level lock for this test instance. Its `request()` helper reads the response body and returns to the test thread. The failing assertion inspects the server's lock immediately afterward, without synchronizing on completion of the server request handler.
- `src/open_intelligence/__main__.py:81` acquires the literature lock before the provider call.
- Both expected and unexpected provider-error branches call `_literature_error()` while still inside the protected `try` block. Successful results also call `_json()` inside that block.
- `_literature_error()` calls `_json()`. `_json()` calls `_send()`, which sends a `Content-Length` header and writes the response body to the socket.
- `src/open_intelligence/__main__.py:103` releases the lock in the outer `finally`, after the response-writing call returns.

### Diagnosis

The test observes HTTP response completion, but asserts an internal state that changes at handler cleanup. Those are separate events. The client may read all bytes promised by `Content-Length` and resume its assertion while the request thread is still returning from the socket write, before the `finally` releases the lock.

The source ordering supplies a concrete race mechanism. The change in the failing exception case between runs is consistent with thread scheduling, rather than a missing cleanup branch unique to one provider error. The successful following subtest further argues against a permanently leaked lock: it reaches the expected provider-error response instead of receiving the busy response.

This is strong evidence of a response/cleanup synchronization race. It is not evidence that provider failures permanently retain the lock, and it is not evidence that the error-redaction behavior failed. The exact scheduling interleaving was not instrumented, so no claim is made about its duration.

### Boundary for follow-up

No fix was attempted. A separate owner should decide whether the intended contract requires releasing the request lock before response completion or whether the test should explicitly synchronize with handler cleanup. An arbitrary sleep would conceal the ordering issue. The frontend redesign should retain this failure in its baseline comparison rather than claiming a green Python baseline.

## 2. Fresh workspace database: initial HTTP timeout did not reproduce

### Observed

In the initial full suite, `WorkspaceStartHttpTests.test_fresh_database_to_case_and_exact_uploaded_bytes_survives_reopen` errored at its first operation:

```text
tests/test_workspace_start_http.py:30
self.assertEqual(self.read('/api/cases'), [])
```

The client uses `urlopen(..., timeout=5)` and timed out while waiting for the HTTP response status. The log also contains a later `BrokenPipeError` from the server while writing the `/api/cases` response.

In the single targeted rerun, this unchanged method passed, including case creation, import, reopening the store, and checking the exact uploaded-byte hash and content. The combined two-method run took 0.949 seconds. This is a non-reproduction of the initial timeout, not proof that it cannot recur.

### Source evidence

- The test creates a fresh temporary database path and constructs `ThreadingHTTPServer` before starting its serving thread. The listening socket therefore exists before the first client call; the record does not support describing this as an unbound-port failure.
- `src/open_intelligence/workspace_host.py` delegates `/api/cases` to the existing handler. Its special HTML composition does not run on this request.
- `src/open_intelligence/__main__.py` constructs a new `CaseStore` before querying cases and writing the response.
- `src/open_intelligence/store.py:475` opens SQLite with a ten-second connection timeout, applies the schema, checks migrations, and commits as part of initialization. `CaseStore.cases()` then performs a simple case-list query.
- The failing first request does not invoke a browser or an external literature/model service.

### Diagnosis and limits

The initial run establishes a five-second request timeout and a subsequent write to a client that had closed its connection. The `BrokenPipeError` is consistent with that sequence; it does not identify the cause of the delay.

Initialization of the fresh database, filesystem or scheduling delay, and other transient execution conditions are possible locations of the latency. The initial log has no timing instrumentation around those boundaries, so none can be declared the root cause. The ten-second SQLite timeout exceeds the client's five-second timeout, but that configuration alone does not prove lock contention. This first request uses a new temporary database, and no competing connection is demonstrated in the failure record.

Classify this as an observed baseline HTTP timeout that did not reproduce in the one authorized targeted rerun. Do not call it fixed, a confirmed database bug, or a confirmed environment defect. Further investigation would require scoped timing evidence if the issue recurs; no additional reruns or backend modifications were made here.

## Implications for the frontend change

1. The Python baseline is not green: retain the original full-suite result and the targeted result together.
2. The literature assertion has a clear ordering race mechanism in unchanged source. A later different failure count is not sufficient evidence that a UI change caused or repaired it.
3. The workspace timeout remains unresolved despite the passing targeted method.
4. The initial UI journey produced no screenshots or visual-verification report. Any subsequent browser run must have its own provenance and should not replace the original missing-browser log.
5. This diagnosis changes no source behavior or acceptance criteria.

## Inspected source files

- `tests/test_literature_http.py`
- `tests/test_workspace_start_http.py`
- `src/open_intelligence/__main__.py`
- `src/open_intelligence/workspace_host.py`
- `src/open_intelligence/store.py`

All evidence files mentioned above are siblings of this document under `ux-evidence/before/`.
