# Workspace startup execution evidence

This archive preserves all JSON/log/text receipts, all final focused screenshots,
all review-regression screenshots, and representative intermediate failure
screenshots. Other screenshots and complete source ZIPs remain identified by the
hosted artifact IDs and verified digests in receipts.json. Immutable verification
commits identify the source snapshots. No synthetic data is derived from real
patient records.

The final published revision and its exact-head verification are recorded in
PR #183 after this repository snapshot is committed. The full-candidate section
is actual successful execution, distinct from that later publication gate.
